// Re-export dashboard as index page
// The full implementation is in dashboard.tsx
// This file makes /mall-admin/ route work in Next.js

export { default } from './dashboard';
